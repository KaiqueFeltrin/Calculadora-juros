function calcularJurosSimples() {
    var principal = parseFloat(document.getElementById("principal").value);
    var taxa = parseFloat(document.getElementById("taxa").value);
    var periodo = parseFloat(document.getElementById("periodo").value);
    
    var juros = (principal * taxa * periodo) / 100;
    var valorFuturo = principal + juros;

    document.getElementById("resultado").innerHTML = "Valor Futuro (Juros Simples): R$ " + valorFuturo.toFixed(2);
}

function calcularJurosCompostos() {
    var principal = parseFloat(document.getElementById("principal").value);
    var taxa = parseFloat(document.getElementById("taxa").value);
    var periodo = parseFloat(document.getElementById("periodo").value);

    var valorFuturo = principal * (1 + taxa / 100) ** periodo;

    document.getElementById("resultado").innerHTML = "Valor Futuro (Juros Compostos): R$ " + valorFuturo.toFixed(2);
}


parseFloat //parseFloat transforma os números em decimal.
toFixed //arredonda o número para cima.
innerHTML //retorna o conteúdo HTML 



